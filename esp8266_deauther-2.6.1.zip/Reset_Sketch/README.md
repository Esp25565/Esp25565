# RESET

## Method 1

Open the Reset_Sketch.ino and upload with the correct settings.  

## Method 2

Flash one of the `reset_` files.  

## Method 3

Flash the `blank_1MB.bin` to 0x000000 for 1MB modules.  
Flash it to 0x000000, 0x100000, 0x200000 and 0x300000 for 4MB modules.  